% Copyright 2018 - 2020 The MathWorks, Inc.
Ts = 0.01;